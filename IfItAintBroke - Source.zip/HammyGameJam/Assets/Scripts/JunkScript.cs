﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using Random = UnityEngine.Random;

public class JunkScript : MonoBehaviour
{

    private Animator anim;

    private AudioSource audio;

    private int junkType;

    private bool topConveyor;

    public int speed;

    private double despawnX;

    private Rigidbody2D rb;



    
    public AudioClip Nice;
    public AudioClip OhNo;

    // Start is called before the first frame update
    void Start()
    {

        audio = GetComponent<AudioSource>();
        //initialises the animator and works out what sort of junk this is
        anim = GetComponent<Animator>();
        junkType = Random.Range(0, 3); //int Random.Range is exclusive of top
        //gives it the appropriate appearance
        switch (junkType)
        {
            case 0:
                anim.SetTrigger("fixed");
                transform.tag = "FixedJunk";
                break;
            case 1:
                anim.SetTrigger("needsOil");
                break;
            case 2:
                anim.SetTrigger("needsTape");
                break;

        }


        topConveyor = (Random.Range(0f, 1f) >= 0.5f);
        //randomly assigned to top conveyor or bottom conveyor, and y co-ordinate set appropriately
        if (topConveyor)
        {
            speed = -speed; //will travel to the right instead
            transform.position = new Vector2(5f, 2);
            despawnX = -5;
        }
        else
        {

            transform.position = new Vector2(-5f, -2);
            despawnX = 5;
        }

        //now sorts out the speed stuff
        rb = GetComponent<Rigidbody2D>();
        rb.velocity = new Vector3(speed, 0f);
        //allows this to constantly move

    }

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.CompareTag("PlayerOil"))
        {
            //if a player with oil interacted with it
            anim.SetTrigger("oilGiven");
            if (junkType == 1)
            {
                junkType = 0; //fixed if it needed oil
                transform.tag = "FixedJunk";
                audio.PlayOneShot(Nice, 1f);
            }
            else
            {
                junkType = 3; //broke if it didn't need oil
                transform.tag = "BrokeJunk";
                audio.PlayOneShot(OhNo, 1f);
            }
        }
        else if (other.CompareTag("PlayerTape"))
        {
            //if a player with tape interacted with it
            anim.SetTrigger("tapeGiven");
            if (junkType == 2)
            {
                junkType = 0; //fixed if if needed tape
                transform.tag = "FixedJunk";
                audio.PlayOneShot(Nice, 1f);
            }
            else
            {
                junkType = 3; //broke if it needed tape
                transform.tag = "BrokeJunk";
                audio.PlayOneShot(OhNo,1f);
            }
        }
    }


    //updates once per frame, checking if the junk should be despawning or not
    void FixedUpdate()
    {
        CheckForOutOfBounds();
    }

    void CheckForOutOfBounds()
    {

        if (topConveyor)
        {
            if (transform.position.x <= despawnX)
            {
                Destroy(gameObject);
            }
        }
        else
        {
            if (transform.position.x >= despawnX)
            {
                Destroy(gameObject);
            }
        }


    }


}