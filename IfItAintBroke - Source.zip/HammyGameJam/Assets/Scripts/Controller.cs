﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Controller : MonoBehaviour
{

    public string scoreString;
    public Text scoreText;

    public int score;

    public int scoreToRegainStrike;
    private int scoreUntilStrikeIsRegained;

    public GameObject strikeCounter;

    private Animator strikeCounterAnimator;

    public JunkSpawner junkSpawner;

    public int strikes;

    public Boolean gameOver;

    public AudioClip youFailed;

    private AudioSource audio;

    public GameObject uFailed;

    private bool pressingKey;

    // Start is called before the first frame update
    void Start()
    {
        audio = GetComponent<AudioSource>();
        scoreUntilStrikeIsRegained = scoreToRegainStrike;
        gameOver = false;
        pressingKey = false;

        //obtaining the animator for the score counter
        strikeCounterAnimator = strikeCounter.GetComponent<Animator>();

        scoreText.text = scoreString + score.ToString();

    }

    // Update is called once per frame
    void Update()
    {
        if (gameOver && Input.anyKey) //if the game is over and the user is pressing any key, it goes back to the menu
        {
            SceneManager.LoadScene(0);
        }

    }

    void OnGUI()
    {
        //only attempts to proceed if a user has lifted a key after pressing it,
        //so people don't accidentally skip past the 'u failed' screen when it appears
        Event e = Event.current;
        if (e.type == EventType.KeyDown && !pressingKey)
        {

            pressingKey = true;
            if (gameOver)
            {
                SceneManager.LoadScene(0);
            }
        }
        else if (e.type == EventType.KeyUp && pressingKey)
        {
            pressingKey = false;
        }
    }

    public void increaseScore()
    {
        if (!gameOver)
        {
            score++;

            //Debug.Log("Score: " + score.ToString());

            //updating score counter

            scoreText.text = scoreString + score.ToString();



            if (scoreUntilStrikeIsRegained == 0 && strikes < 3) //if the player is due a returned strike and not already at max strikes
            {
                if (strikes > 0)
                {
                    strikes--; //player has a strike taken away if they had a strike
                    strikeCounterAnimator.SetTrigger("extra chance");
                }
                //Debug.Log("-1 Strike, current strikes: " + strikes.ToString());
                scoreUntilStrikeIsRegained = scoreToRegainStrike;

            

            }
            else
            {
                scoreUntilStrikeIsRegained--; //counts down until the strike is regained
            }
        }
    }


    public void strike()
    {

        strikes++;

        //Debug.Log("Strikes: " + strikes.ToString());

        if (strikes < 4) //ensuring that there are no issues if any more boxes go in after the game ends
        {
            strikeCounterAnimator.SetTrigger("oh no you dun goofed");
        }

        if (strikes >= 3)
        {
            //will stop the game when the player has 3 strikes (or more)
            gameOverMethod();
                
           
        }
    }

    void gameOverMethod()
    {
        junkSpawner.stopSpawning();
        //Debug.Log("Game over yeah!");
        audio.PlayOneShot(youFailed, 1f);
        GameObject uSuckLmao = Instantiate(uFailed);
        gameOver = true;

    }
}
