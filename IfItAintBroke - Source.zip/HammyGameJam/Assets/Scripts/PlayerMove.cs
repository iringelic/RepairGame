﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public float speed; //how fast it moves

    public float xBoundary; //how far it can move from the middle in x direction
    public float yBoundary; //how far it can move from the middle in y boundary

    // FixedUpdate is called regularly
    void FixedUpdate()
    {
        float x = Input.GetAxisRaw("Horizontal"); //obtains horizontal input. GetAxis: gradual acceleration, GetAxisRaw: immediate acceleration
        float y = Input.GetAxisRaw("Vertical");
        Vector2 movement = new Vector2(x * speed * Time.fixedDeltaTime, y * speed * Time.fixedDeltaTime); //gets the movement for this update as 2d vector; fixedDeltaTime makes it not too fast
        transform.position = transform.position + (Vector3)movement; //updates position for the player object, but treating the new movement as a 3d vector
        transform.position = new Vector2(
            Mathf.Clamp(transform.position.x, -xBoundary, xBoundary),
            Mathf.Clamp(transform.position.y, -yBoundary, yBoundary)
        ); //prevents it from going over the boundary in the x and y axis


    }
}
