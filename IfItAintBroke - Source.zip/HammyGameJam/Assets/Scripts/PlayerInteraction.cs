﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInteraction : MonoBehaviour
{

    private Animator anim;

    public int heldItem;

    void Start()
    {
        anim = GetComponent<Animator>();
        //heldItem = 0;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        //If the object this object collided with is a TapeZone, get tape
        if (other.CompareTag("TapeZone"))
        {
            //Debug.Log("tape");
            anim.SetTrigger("tape");
            transform.tag = "PlayerTape";
            //heldItem = 1;
            

        } else if (other.CompareTag("OilZone"))
        {
            //get oil if touching the oil zone
            //Debug.Log("oil");
            anim.SetTrigger("oil");
            transform.tag = "PlayerOil";
            //heldItem = 2;
            

        } else if (other.CompareTag("Junk") || other.CompareTag("FixedJunk") || other.CompareTag("BrokeJunk"))
        {
            //another else if statement to discard current held item if interacting with some junk
            //Debug.Log("junk");
            anim.SetTrigger("usedItem");
            transform.tag = "Player";
            //heldItem = 0;

        }

    }
}
