﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class How2PlayScript : MonoBehaviour
{

    private Animator anim;

    private int animationStage;

    private bool pressingKey;

    // Start is called before the first frame update
    void Start()
    {
        animationStage = 0;
        anim = GetComponent<Animator>();
        pressingKey = false;

    }

    // Update is called once per frame
    void OnGUI()
    {
        Event e = Event.current;

        //only attempts to proceed if a user has lifted a key after pressing it,
        //so people don't accidentally skip through the how 2 play presentation
        if (e.type == EventType.KeyDown && !pressingKey)
        { 

            pressingKey = true;
            if (animationStage < 5)
            {

                anim.SetTrigger("NextAnimation");
                animationStage++;
            }
            else
            {
                SceneManager.LoadScene(0);
            }
        } else if (e.type == EventType.KeyUp && pressingKey)
        {
            pressingKey = false;
        }
    }

}
