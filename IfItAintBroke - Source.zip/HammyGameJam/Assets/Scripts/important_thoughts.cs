﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class important_thoughts : MonoBehaviour
{

    private TMP_Text thePlaceForTheImportantThoughts;
    // Start is called before the first frame update
    void Start()
    {
        thePlaceForTheImportantThoughts = GetComponent<TMP_Text>();

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void hmm()
    {
        //here are some important thoughts for the user to see
        int shroomyspear = Random.Range(0, 51);
        string bigThonk = "";

        switch (shroomyspear)
        {
            case 0:
                bigThonk = "We should start World War 4 sooner, as that can only start when World War 3 is over, so the sooner we have WW4, the sooner we'll be done with WW3.";
                break;
            case 1:
                bigThonk = "im gonna write a hunger games musical";
                break;
            case 2:
                bigThonk = "what if dogs were green\nwouldn't that be funny?";
                break;
            case 3:
                bigThonk = "vibe check";
                break;
            case 4:
                bigThonk = "what is an updog?";
                break;
            case 5:
                bigThonk = "dank";
                break;
            case 6:
                bigThonk = "CIA, pronounced as a word and not as initialism, is what the agents say right before they shoot you. \"See (y) ahh!\"\nAlso their ice cream vans are tasty.";
                break;
            case 7:
                bigThonk = "lays potato chip";
                break;
            case 8:
                bigThonk = "Punching a nazi should legally be considered an act of self-defense. After all, their entire ideology revolves around killing others, y'know?";
                break;
            case 9:
                bigThonk = "you ever just find yourself making shitposts in your game jam game at 11pm and need to get bread but tesco closes at midnight?";
                break;
            case 10:
                bigThonk = "Penne, ma e un crimine di guerra";
                break;
            case 11:
                bigThonk = "bones itch";
                break;
            case 12:
                bigThonk = "what if harry potter (from harry potter (the book (or the movie))) carried a glock 17";
                break;
            case 13:
                bigThonk = "chair police would be cool if they arrested bad chairs";
                break;
            case 14:
                bigThonk = "uh oh thinky";
                break;
            case 15:
                bigThonk = "Thanks but I can see you there gold, I don't want to die of a stroke too";
                break;
            case 16:
                bigThonk = "thomas jefferson invented swivel chair so his head on a mountain, thats deep.";
                break;
            case 17:
                bigThonk = "I love eating water";
                break;
            case 18:
                bigThonk =
                    "help I am being held hostage and forced to produce these important thoughts for your amusement please help me I am being held at OH HECC THEY FOUND ME AAUGHH *painful noises*";
                break;
            case 19:
                bigThonk = "potate";
                break;
            case 20:
                bigThonk =
                    "nom nom nom hot chip mmm tastes hot and like chip";
                break;
            case 21:
                bigThonk = "abraham linkedin";
                break;
            case 22:
                bigThonk = "congrats u found the hidden messages and such yey";
                break;
            case 23:
                bigThonk = "Gend'er? I hardly know them!";
                break;
            case 24:
                bigThonk = "Beep beep another one bites the sheep";
                break;
            case 25:
                bigThonk = "Lego city should make vehicles before a problem is presented not during it";
                break;
            case 26:
                bigThonk = "grass grow in the dirt";
                break;
            case 27:
                bigThonk =
                    "Instead of using 'he/she', 'he or she', etc in your writing, just use 'they'. Easier to write, easier to say, and more inclusive, y'know?";
                break;
            case 28:
                bigThonk = "without sauce we are cavemen";
                break;
            case 29:
                bigThonk = "trans rights";
                break;
            case 30:
                bigThonk = "Are pickled pickles picklest";
                break;
            case 31:
                bigThonk = "Why are cows?";
                break;
            case 32:
                bigThonk = "Speakers have little people inside shouting and singing";
                break;
            case 33:
                bigThonk = "Vinegar is the spicy of the water";
                break;
            case 34:
                bigThonk = "We should farm dinosaurs for oil";
                break;
            case 35:
                bigThonk =
                    "You may consume 1 (One) cookie (or other small-sized snack which is in a convenient location nearby)";
                break;
            case 36:
                bigThonk = "Minecraft earth Minecraft Mars Minecraft nether";
                break;
            case 37:
                bigThonk = "When in doubt, use your upper mouth";
                break;
            case 38:
                bigThonk = "Electric chairs aren't made out of electricity";
                break;
            case 39:
                bigThonk = "According to all known laws of aviation a brick shouldn't be able to fly, so it doesn't";
                break;
            case 40:
                bigThonk = "sharks are scary whales";
                break;
            case 41:
                bigThonk = "why yes I am a real gamer that is why I pronounce videogames as 'blideo bames', I struggle passing a level on Microsoft Excel 2007, my game collection is just every season of Frasier, "+
                           "my XBox One is a series of tissue boxes glued together with the word 'NINTEMDO' painted over it, I backflip away when asked about my favourite videogame, "+
                           "and I keep a secret diary saying how much I absolutely hate video games";
                break;
            case 42:
                bigThonk = "Don't panic.";
                break;
            case 43:
                bigThonk = "My sauce needs to boil for 7 more minutes";
                break;
            case 44:
                bigThonk = "It's  either real or it's a dream there's no such thing as a fake meme";
                break;
            case 45:
                bigThonk =
                    "On trial for a crime you committed? Just ban anyone from presenting any evidence at your trial lmao";
                break;
            case 46:
                bigThonk = "Green apples are actually apples that can't decide to be yellow or blue";
                break;
            case 47:
                bigThonk = "cookie book";
                break;
            case 48:
                bigThonk = "QR code with a link to 'never gonna give you up' goes here";
                break;
            case 49:
                bigThonk = "What if pufferfishes sounded like plastic bags when they deflated";
                break;
            case 50:
                bigThonk = "<b>PLEASE BECOME FUNNY</b>" + 
                           "\n\n\n-<i>Ben \"Kylo Ren\" Solo, 2020</i>";
                break;

        }

        //shows these important thoughts to the user
        thePlaceForTheImportantThoughts.text = bigThonk;
    }
}
