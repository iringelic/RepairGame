using UnityEngine.SceneManagement;
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OptionsButton : MonoBehaviour
{
    // Start is called before the first frame update
    public void Start()
    {

    }

    // Update is called once per frame
    public void Update()
    {

    }

    public void LoadOptions() {
      SceneManager.LoadScene(2);
    }
}
