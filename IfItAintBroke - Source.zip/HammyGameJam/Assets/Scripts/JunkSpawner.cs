﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class JunkSpawner : MonoBehaviour
{
    // Start is called before the first frame update

    public GameObject junk;

    public int intensity;

    public int finalIntensity;

    public int intensityIncreaseRate;

    private int intensityIncreaseCountdown;

    private float timer;

    public float minDelay;
    public float maxDelay;

    private Boolean canSpawn;

    void Start()
    {
        intensityIncreaseCountdown = intensityIncreaseRate;
        canSpawn = true;
    }

    void FixedUpdate()
    {
        if (canSpawn) //if its allowed to try spawning junk
        {


            if (timer > 0f)
                timer = timer - Time.fixedDeltaTime; //Decrease the time until it will attempt spawning a box

            if (timer <= 0f)
            {

                timer = Random.Range(minDelay, maxDelay); //delay until it next attempts spawning a box

                //gets closer to ramping up the rate at which boxes appear
                intensityIncreaseCountdown--;
                if (intensityIncreaseCountdown == 0)
                {
                    if (intensity < finalIntensity)
                    {
                        intensity++;
                        intensityIncreaseCountdown = (int) (intensityIncreaseRate * (Random.Range(0.9f, 1.1f)));
                        //sets the intensity increase countdown back to the start (or thereabouts)
                    }
                }

                if (Random.Range(0, finalIntensity) <= intensity)
                {
                    //only spawns some junk if the randomly generated number is below or equal to the current intensity value 
                    GameObject someMoreJunk = Instantiate(junk);
                }
            }

        }
    }

    public void stopSpawning()
    {
        canSpawn = false; //no more spawning allowed >:(
    }

}
