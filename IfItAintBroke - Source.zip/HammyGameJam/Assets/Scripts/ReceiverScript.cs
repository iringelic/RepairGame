﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ReceiverScript : MonoBehaviour
{


    public Controller gameController;


    public AudioClip OhNo;
    private AudioSource audio;

    // Start is called before the first frame update
    void Start()
    {
        audio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("FixedJunk"))
        {
            //nice if it gets some fixed junk
            //Debug.Log("nice");

            gameController.increaseScore();

        } else if (other.CompareTag("BrokeJunk") || other.CompareTag("Junk"))
        {
            //not good if it gets fixedn't junk
            //Debug.Log("uh oh");
            if (other.CompareTag("Junk"))
            {
                audio.PlayOneShot(OhNo, 1f);
                //they didn't even attempt fixing that junk? bruh
            }

            gameController.strike();
        }
    }
}
